# Did You Miss Cycy?

A cute interactive web page that asks "Did you miss Cycy?" with:

- Forest background at night 🌲
- Animated "No" button
- Sweet message on "Yes"
- Background music (`music.mp3`, not included)

## How to Use

1. Upload this folder to GitHub
2. Add your own `music.mp3` file
3. Enable GitHub Pages from the repository settings
4. Share the live link 😄

Made with ❤️
